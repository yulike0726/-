import os
import json
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_wtf.csrf import CSRFProtect, generate_csrf
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

# 初始化Flask应用
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'  # 请替换为随机字符串
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///schedule.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# 初始化扩展
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
csrf = CSRFProtect(app)

# 春季/冬季作息配置
SCHEDULE_CONFIGS = {
    'spring': {
        1: "08:00-08:50",
        2: "09:00-09:50",
        3: "10:10-11:00",
        4: "11:10-12:00",
        5: "14:30-15:20",
        6: "15:30-16:20",
        7: "16:30-17:20",
        8: "17:30-18:20",
        9: "19:00-19:50",
        10: "20:00-20:50",
        11: "21:00-21:50",
        12: "22:00-22:50"
    },
    'winter': {
        1: "08:00-08:50",
        2: "09:00-09:50",
        3: "10:10-11:00",
        4: "11:10-12:00",
        5: "14:00-14:50",
        6: "15:00-15:50",
        7: "16:00-16:50",
        8: "17:00-17:50",
        9: "19:00-19:50",
        10: "20:00-20:50",
        11: "21:00-21:50",
        12: "22:00-22:50"
    }
}


# 数据库模型
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    current_schedule_type = db.Column(db.String(20), default='spring', nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class SemesterSetting(db.Model):
    __tablename__ = 'semester_settings'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    start_date = db.Column(db.String(20), nullable=False)

    user = db.relationship('User', backref=db.backref('semester_setting', uselist=False))


class Schedule(db.Model):
    __tablename__ = 'schedules'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    course_name = db.Column(db.String(100), nullable=False)
    weekday = db.Column(db.Integer, nullable=False)
    section_start = db.Column(db.Integer, nullable=False)
    section_end = db.Column(db.Integer, nullable=False)
    section = db.Column(db.String(20), nullable=False)
    class_time = db.Column(db.String(50), nullable=False)
    week_range = db.Column(db.String(50), nullable=False)
    repeat_type = db.Column(db.String(20), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    teacher = db.Column(db.String(80), nullable=False)
    color = db.Column(db.String(20), default='#4285F4', nullable=False)

    user = db.relationship('User', backref=db.backref('schedules', lazy=True))
    homeworks = db.relationship('Homework', backref='schedule', lazy=True, cascade='all, delete-orphan')


class Homework(db.Model):
    __tablename__ = 'homeworks'
    id = db.Column(db.Integer, primary_key=True)
    schedule_id = db.Column(db.Integer, db.ForeignKey('schedules.id'), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    deadline = db.Column(db.String(50), nullable=False)
    is_completed = db.Column(db.Boolean, default=False, nullable=False)
    task_type = db.Column(db.String(20), default='homework', nullable=False)

    user = db.relationship('User', backref=db.backref('homeworks', lazy=True))


# 用户加载回调
# ========== 修改点1：适配SQLAlchemy 2.0，避免警告 ==========
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))  # 替代原有的 User.query.get(int(user_id))


# 辅助函数：计算当前周数
def calculate_week(start_date, current_date=None):
    if not current_date:
        current_date = datetime.now()
    start = datetime.strptime(start_date, '%Y-%m-%d')
    days_diff = (current_date - start).days
    week = max(1, min(20, (days_diff // 7) + 1))
    return week


# 辅助函数：解析周范围
def parse_week_range(week_range_str):
    weeks = []
    week_range_str = week_range_str.replace('周', '')

    # 处理逗号分隔
    for part in week_range_str.split(','):
        part = part.strip()
        if '-' in part:
            start_end = part.split('-')
            if len(start_end) == 2:
                try:
                    start = int(start_end[0])
                    end = int(start_end[1])
                    weeks.extend(range(start, end + 1))
                except:
                    pass
        else:
            try:
                weeks.append(int(part))
            except:
                pass
    return list(set(weeks))


# 路由
@app.route('/')
@login_required
def index():
    # 获取学期设置
    semester_setting = SemesterSetting.query.filter_by(user_id=current_user.id).first()
    start_date = semester_setting.start_date if semester_setting else datetime.now().strftime('%Y-%m-01')

    # 计算当前周数
    current_week = calculate_week(start_date)

    # ========== 修改点2：传递作息配置到前端，用于课表时间显示 ==========
    return render_template('schedule.html',
                           username=current_user.username,
                           current_week=current_week,
                           schedule_configs=SCHEDULE_CONFIGS)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('用户名或密码错误')

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # 检查用户名和邮箱是否已存在
        if User.query.filter_by(username=username).first():
            flash('用户名已存在')
            return render_template('register.html')

        if User.query.filter_by(email=email).first():
            flash('邮箱已存在')
            return render_template('register.html')

        # 创建新用户
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)

        # 关键修复：先flush生成user.id（不提交事务）
        db.session.flush()

        # 创建默认学期设置（此时user.id已生成）
        default_start = datetime.now().strftime('%Y-%m-01')
        semester = SemesterSetting(user_id=user.id, start_date=default_start)
        db.session.add(semester)

        # 最后统一提交事务
        db.session.commit()
        flash('注册成功，请登录')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


# API路由
@app.route('/api/csrf-token')
def get_csrf_token():
    return jsonify({'csrf_token': generate_csrf()})


@app.route('/api/semester/setting', methods=['GET'])
@login_required
def get_semester_setting():
    setting = SemesterSetting.query.filter_by(user_id=current_user.id).first()
    if setting:
        return jsonify({
            'success': True,
            'data': {'start_date': setting.start_date}
        })
    else:
        default_date = datetime.now().strftime('%Y-%m-01')
        return jsonify({
            'success': True,
            'data': {'start_date': default_date}
        })


@app.route('/api/semester/setting', methods=['POST'])
@login_required
def set_semester_setting():
    data = request.get_json()
    start_date = data.get('start_date')

    setting = SemesterSetting.query.filter_by(user_id=current_user.id).first()
    if setting:
        setting.start_date = start_date
    else:
        setting = SemesterSetting(user_id=current_user.id, start_date=start_date)
        db.session.add(setting)

    db.session.commit()
    return jsonify({'success': True, 'msg': '学期设置保存成功'})


@app.route('/api/schedules', methods=['POST'])
@login_required
def add_schedule():
    data = request.get_json()

    # 解析节次
    section_str = data.get('section')
    if '-' in section_str:
        section_parts = section_str.split('-')
        section_start = int(section_parts[0])
        section_end = int(section_parts[1])
    else:
        section_start = int(section_str)
        section_end = int(section_str)

    schedule = Schedule(
        user_id=current_user.id,
        course_name=data.get('course_name'),
        weekday=int(data.get('weekday')),
        section_start=section_start,
        section_end=section_end,
        section=section_str,
        class_time=data.get('class_time'),
        week_range=data.get('week_range'),
        repeat_type=data.get('repeat_type'),
        location=data.get('location'),
        teacher=data.get('teacher'),
        color=data.get('color')
    )

    db.session.add(schedule)
    db.session.commit()

    return jsonify({'success': True, 'msg': '课程添加成功'})


@app.route('/api/schedules/<int:schedule_id>', methods=['PUT'])
@login_required
def update_schedule(schedule_id):
    schedule = Schedule.query.filter_by(id=schedule_id, user_id=current_user.id).first()
    if not schedule:
        return jsonify({'success': False, 'msg': '课程不存在'}), 404

    data = request.get_json()

    # 解析节次
    section_str = data.get('section')
    if '-' in section_str:
        section_parts = section_str.split('-')
        section_start = int(section_parts[0])
        section_end = int(section_parts[1])
    else:
        section_start = int(section_str)
        section_end = int(section_str)

    schedule.course_name = data.get('course_name')
    schedule.weekday = int(data.get('weekday'))
    schedule.section_start = section_start
    schedule.section_end = section_end
    schedule.section = section_str
    schedule.class_time = data.get('class_time')
    schedule.week_range = data.get('week_range')
    schedule.repeat_type = data.get('repeat_type')
    schedule.location = data.get('location')
    schedule.teacher = data.get('teacher')
    schedule.color = data.get('color')

    db.session.commit()

    return jsonify({'success': True, 'msg': '课程更新成功'})


@app.route('/api/schedules/<int:schedule_id>', methods=['DELETE'])
@login_required
def delete_schedule(schedule_id):
    schedule = Schedule.query.filter_by(id=schedule_id, user_id=current_user.id).first()
    if not schedule:
        return jsonify({'success': False, 'msg': '课程不存在'}), 404

    db.session.delete(schedule)
    db.session.commit()

    return jsonify({'success': True, 'msg': '课程删除成功'})


@app.route('/api/schedules/week/<int:week>', methods=['GET'])
@login_required
def get_week_schedules(week):
    # 限制周数范围
    week = max(1, min(20, week))

    # 获取所有课程
    all_schedules = Schedule.query.filter_by(user_id=current_user.id).all()
    show_schedules = []

    for schedule in all_schedules:
        # 解析周范围
        weeks = parse_week_range(schedule.week_range)

        # 检查是否在当前周显示
        show = False
        if week in weeks:
            if schedule.repeat_type == 'weekly':
                show = True
            elif schedule.repeat_type == 'odd' and week % 2 == 1:
                show = True
            elif schedule.repeat_type == 'even' and week % 2 == 0:
                show = True

        if show:
            show_schedules.append({
                'id': schedule.id,
                'course_name': schedule.course_name,
                'weekday': schedule.weekday,
                'section_start': schedule.section_start,
                'section_end': schedule.section_end,
                'section': schedule.section,
                'class_time': schedule.class_time,
                'week_range': schedule.week_range,
                'repeat_type': schedule.repeat_type,
                'location': schedule.location,
                'teacher': schedule.teacher,
                'color': schedule.color
            })

    # 获取当前用户的作息配置
    current_schedule = SCHEDULE_CONFIGS.get(
        current_user.current_schedule_type,
        SCHEDULE_CONFIGS['spring']
    )

    return jsonify({
        'success': True,
        'data': show_schedules,
        'section_times': current_schedule
    })


@app.route('/api/schedules/<int:schedule_id>/homeworks', methods=['GET'])
@login_required
def get_schedule_homeworks(schedule_id):
    homeworks = Homework.query.filter_by(
        schedule_id=schedule_id,
        user_id=current_user.id
    ).order_by(Homework.deadline).all()

    homework_list = []
    for hw in homeworks:
        homework_list.append({
            'id': hw.id,
            'content': hw.content,
            'deadline': hw.deadline,
            'is_completed': hw.is_completed,
            'task_type': hw.task_type
        })

    return jsonify({'success': True, 'data': homework_list})


@app.route('/api/homeworks', methods=['POST'])
@login_required
def add_homework():
    data = request.get_json()

    homework = Homework(
        user_id=current_user.id,
        schedule_id=data.get('schedule_id'),
        content=data.get('content'),
        deadline=data.get('deadline'),
        is_completed=data.get('is_completed', False),
        task_type=data.get('task_type', 'homework')
    )

    db.session.add(homework)
    db.session.commit()

    return jsonify({'success': True, 'msg': '作业添加成功'})


@app.route('/api/homeworks/<int:homework_id>', methods=['PUT'])
@login_required
def update_homework(homework_id):
    homework = Homework.query.filter_by(id=homework_id, user_id=current_user.id).first()
    if not homework:
        return jsonify({'success': False, 'msg': '作业不存在'}), 404

    data = request.get_json()

    homework.schedule_id = data.get('schedule_id')
    homework.content = data.get('content')
    homework.deadline = data.get('deadline')
    homework.is_completed = data.get('is_completed', False)
    homework.task_type = data.get('task_type', homework.task_type)

    db.session.commit()

    return jsonify({'success': True, 'msg': '作业更新成功'})


# ========== 修改点3：新增作业完成状态切换API ==========
@app.route('/api/homeworks/<int:homework_id>/complete', methods=['POST'])
@login_required
def toggle_homework_complete(homework_id):
    # 查找当前用户的作业（防止越权访问）
    homework = Homework.query.filter_by(id=homework_id, user_id=current_user.id).first()
    if not homework:
        return jsonify({'success': False, 'msg': '作业不存在'}), 404

    # 切换完成状态（取反）
    homework.is_completed = not homework.is_completed
    db.session.commit()

    # 返回更新后的状态
    return jsonify({
        'success': True,
        'msg': '作业状态更新成功',
        'data': {'is_completed': homework.is_completed}
    })


@app.route('/api/homeworks/<int:homework_id>', methods=['DELETE'])
@login_required
def delete_homework(homework_id):
    homework = Homework.query.filter_by(id=homework_id, user_id=current_user.id).first()
    if not homework:
        return jsonify({'success': False, 'msg': '作业不存在'}), 404

    db.session.delete(homework)
    db.session.commit()

    return jsonify({'success': True, 'msg': '作业删除成功'})


@app.route('/api/homeworks/all', methods=['GET'])
@login_required
def get_all_homeworks():
    homeworks = Homework.query.filter_by(user_id=current_user.id).order_by(Homework.deadline).all()

    homework_list = []
    for hw in homeworks:
        # 获取课程名称
        course_name = '独立任务'
        if hw.schedule_id:
            schedule = Schedule.query.get(hw.schedule_id)
            if schedule:
                course_name = schedule.course_name

        homework_list.append({
            'id': hw.id,
            'content': hw.content,
            'deadline': hw.deadline,
            'is_completed': hw.is_completed,
            'task_type': hw.task_type,
            'schedule_id': hw.schedule_id,
            'course_name': course_name
        })

    return jsonify({'success': True, 'data': homework_list})


@app.route('/api/homeworks/<int:homework_id>', methods=['GET'])
@login_required
def get_homework(homework_id):
    homework = Homework.query.filter_by(id=homework_id, user_id=current_user.id).first()
    if not homework:
        return jsonify({'success': False, 'msg': '作业不存在'}), 404

    return jsonify({
        'success': True,
        'data': {
            'id': homework.id,
            'schedule_id': homework.schedule_id,
            'content': homework.content,
            'deadline': homework.deadline,
            'is_completed': homework.is_completed,
            'task_type': homework.task_type
        }
    })


@app.route('/api/user/schedule-type', methods=['GET'])
@login_required
def get_schedule_type():
    return jsonify({
        'success': True,
        'data': {
            'type': current_user.current_schedule_type
        }
    })


@app.route('/api/user/schedule-type', methods=['POST'])
@login_required
def set_schedule_type():
    data = request.get_json()
    schedule_type = data.get('schedule_type')

    if schedule_type not in SCHEDULE_CONFIGS.keys():
        return jsonify({'success': False, 'msg': '无效的作息类型'}), 400

    current_user.current_schedule_type = schedule_type
    db.session.commit()
    return jsonify({'success': True, 'msg': '作息类型切换成功'})


# 创建数据库表
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    # host='0.0.0.0' 允许局域网其他设备访问，port是端口（可自定义）
    app.run(host='0.0.0.0', port=5000, debug=False)