// 全局变量
let currentDeleteId = null;
let slideStartX = 0;
let slideOffset = 0;

// DOM加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 加载课表数据
    loadSchedules();

    // 筛选周次
    document.getElementById('week-filter').addEventListener('change', loadSchedules);

    // 刷新按钮
    document.getElementById('refresh-btn').addEventListener('click', loadSchedules);

    // 添加课表按钮
    document.getElementById('add-btn').addEventListener('click', function() {
        resetForm();
        document.getElementById('modal-title').textContent = '添加课表';
        openModal();
    });

    // 取消弹窗按钮
    document.getElementById('cancel-btn').addEventListener('click', closeModal);

    // 提交课表表单
    document.getElementById('schedule-form').addEventListener('submit', function(e) {
        e.preventDefault();
        saveSchedule();
    });

    // 取消删除
    document.getElementById('cancel-delete').addEventListener('click', closeConfirmModal);

    // 确认删除
    document.getElementById('confirm-delete').addEventListener('click', function() {
        deleteSchedule(currentDeleteId);
    });
});

// 加载课表数据
function loadSchedules() {
    const loading = document.getElementById('loading');
    const empty = document.getElementById('empty');
    const list = document.getElementById('schedule-list');
    
    // 显示加载状态
    loading.classList.remove('hidden');
    empty.classList.add('hidden');
    
    // 获取筛选条件
    const weekFilter = document.getElementById('week-filter').value;

    // 请求API
    axios.get('/api/schedules')
        .then(response => {
            const schedules = response.data.data;
            loading.classList.add('hidden');
            
            // 筛选周次
            let filtered = schedules;
            if (weekFilter) {
                filtered = schedules.filter(item => item.week.includes(weekFilter));
            }

            // 渲染课表列表
            if (filtered.length === 0) {
                empty.classList.remove('hidden');
                list.innerHTML = '';
                return;
            }

            let html = '';
            filtered.forEach(item => {
                html += `
                <div class="slide-item bg-white rounded-lg shadow-sm overflow-hidden">
                    <div class="slide-delete">
                        <i class="fa fa-trash mr-1"></i>删除
                    </div>
                    <div class="slide-content p-4" data-id="${item.id}">
                        <div class="flex justify-between items-start mb-2">
                            <h3 class="text-lg font-bold text-blue-600">${item.course_name}</h3>
                            <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">${item.week}</span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-700">
                            <div><i class="fa fa-calendar text-gray-500 mr-1"></i> ${item.date}</div>
                            <div><i class="fa fa-clock-o text-gray-500 mr-1"></i> ${item.class_time}</div>
                            <div><i class="fa fa-list-ol text-gray-500 mr-1"></i> 第${item.section}节</div>
                            <div><i class="fa fa-map-marker text-gray-500 mr-1"></i> ${item.location}</div>
                            <div><i class="fa fa-user text-gray-500 mr-1"></i> ${item.teacher}</div>
                        </div>
                        <div class="mt-3 flex gap-2">
                            <button class="edit-btn text-sm bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition-colors">
                                <i class="fa fa-edit mr-1"></i>编辑
                            </button>
                            <button class="delete-btn text-sm bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 transition-colors">
                                <i class="fa fa-trash mr-1"></i>删除
                            </button>
                        </div>
                    </div>
                </div>
                `;
            });

            list.innerHTML = html;

            // 绑定编辑/删除事件
            bindScheduleEvents();

            // 绑定移动端滑动删除事件
            bindSwipeEvents();
        })
        .catch(error => {
            loading.classList.add('hidden');
            showAlert('加载课表失败！', 'error');
            console.error(error);
        });
}

// 绑定课表项事件
function bindScheduleEvents() {
    // 编辑按钮
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.closest('.slide-content');
            const id = item.dataset.id;
            
            // 获取课表详情
            axios.get('/api/schedules')
                .then(response => {
                    const schedule = response.data.data.find(item => item.id == id);
                    if (schedule) {
                        // 填充表单
                        document.getElementById('schedule-id').value = schedule.id;
                        document.getElementById('course_name').value = schedule.course_name;
                        document.getElementById('date').value = schedule.date;
                        document.getElementById('class_time').value = schedule.class_time;
                        document.getElementById('section').value = schedule.section;
                        document.getElementById('week').value = schedule.week;
                        document.getElementById('location').value = schedule.location;
                        document.getElementById('teacher').value = schedule.teacher;

                        // 打开弹窗
                        document.getElementById('modal-title').textContent = '编辑课表';
                        openModal();
                    }
                });
        });
    });

    // 删除按钮
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.closest('.slide-content');
            currentDeleteId = item.dataset.id;
            openConfirmModal();
        });
    });

    // 滑动删除按钮点击
    document.querySelectorAll('.slide-delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.nextElementSibling;
            currentDeleteId = item.dataset.id;
            openConfirmModal();
        });
    });
}

// 绑定移动端滑动事件
function bindSwipeEvents() {
    document.querySelectorAll('.slide-content').forEach(item => {
        item.addEventListener('touchstart', function(e) {
            slideStartX = e.touches[0].clientX;
            slideOffset = 0;
        });

        item.addEventListener('touchmove', function(e) {
            const moveX = e.touches[0].clientX;
            const diff = slideStartX - moveX;
            
            // 只允许向左滑动
            if (diff > 0 && diff <= 80) {
                slideOffset = -diff;
                this.style.transform = `translateX(${slideOffset}px)`;
            }
        });

        item.addEventListener('touchend', function() {
            // 滑动距离超过40px则显示删除按钮
            if (Math.abs(slideOffset) > 40) {
                this.style.transform = 'translateX(-80px)';
            } else {
                this.style.transform = 'translateX(0)';
            }
        });
    });
}

// 保存课表（添加/编辑）
function saveSchedule() {
    const id = document.getElementById('schedule-id').value;
    const data = {
        course_name: document.getElementById('course_name').value,
        date: document.getElementById('date').value,
        class_time: document.getElementById('class_time').value,
        section: document.getElementById('section').value,
        week: document.getElementById('week').value,
        location: document.getElementById('location').value,
        teacher: document.getElementById('teacher').value
    };

    let promise;
    if (id) {
        // 编辑课表
        promise = axios.put(`/api/schedules/${id}`, data);
    } else {
        // 添加课表
        promise = axios.post('/api/schedules', data);
    }

    promise.then(response => {
        closeModal();
        showAlert(response.data.msg, 'success');
        loadSchedules();
    }).catch(error => {
        showAlert('操作失败！', 'error');
        console.error(error);
    });
}

// 删除课表
function deleteSchedule(id) {
    axios.delete(`/api/schedules/${id}`)
        .then(response => {
            closeConfirmModal();
            showAlert(response.data.msg, 'success');
            loadSchedules();
        })
        .catch(error => {
            closeConfirmModal();
            showAlert('删除失败！', 'error');
            console.error(error);
        });
}

// 重置表单
function resetForm() {
    document.getElementById('schedule-form').reset();
    document.getElementById('schedule-id').value = '';
}

// 打开弹窗
// ========== 弹窗通用函数（修复版） ==========
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) {
        alert(`⚠️ 未找到弹窗：${modalId}`);
        return;
    }
    // 强制设置显示样式
    modal.style.display = 'flex';
    modal.style.zIndex = '9999'; // 确保弹窗在最上层
    // 点击外部关闭
    modal.onclick = function(e) {
        if (e.target === modal) {
            closeModal(modalId);
        }
    };
    // 聚焦到第一个输入框（提升体验）
    const firstInput = modal.querySelector('.form-input');
    if (firstInput) {
        firstInput.focus();
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        modal.style.zIndex = '1000';
    }
}

// 打开确认删除弹窗
function openConfirmModal() {
    document.getElementById('confirm-modal').classList.remove('hidden');
}

// 关闭确认删除弹窗
function closeConfirmModal() {
    document.getElementById('confirm-modal').classList.add('hidden');
    currentDeleteId = null;
}

// 显示提示框
function showAlert(message, type) {
    const alert = document.createElement('div');
    alert.className = `fixed top-4 right-4 z-50 px-4 py-2 rounded shadow-lg transition-all duration-500
                       ${type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`;
    alert.textContent = message;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.classList.add('opacity-0');
        setTimeout(() => alert.remove(), 500);
    }, 3000);
}